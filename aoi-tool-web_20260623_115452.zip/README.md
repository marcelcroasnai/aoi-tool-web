# AOI Tool v2.0 — Web Edition

Interfață web modernă pentru inspecția programelor AOI Viscom SI.
Rulează pe **Raspberry Pi**, accesibil din orice browser din rețeaua locală.

---

## Arhitectură

```
Browser (orice PC din rețea)
        ↕  HTTP  (port 3000)
    Frontend React  ──→  Backend FastAPI (port 8000)
                                ↕
                    Drive P:/ montat via CIFS (Samba)
                    Intranet firmă (Auftragsplan)
```

---

## 1. Instalare pe Raspberry Pi

### 1.1 Montare drive P:/ via CIFS

Instalează cifs-utils:
```bash
sudo apt install cifs-utils
```

Creează directorul de mount:
```bash
sudo mkdir -p /mnt/aoi
```

Adaugă în `/etc/fstab` (înlocuiește valorile cu cele reale):
```
//SERVER_IP/aoi  /mnt/aoi  cifs  username=USER,password=PASS,uid=1000,gid=1000,iocharset=utf8  0  0
```

Montează:
```bash
sudo mount -a
```

Verifică:
```bash
ls /mnt/aoi/Viscom_XM/Project/Si/Data/Cad_Ruest/
```

### 1.2 Backend Python

```bash
cd aoi-web/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Pornire:
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

Documentație API automată: `http://<IP_RPI>:8000/docs`

### 1.3 Frontend React

Instalează Node.js pe RPi:
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

Build frontend:
```bash
cd aoi-web/frontend
npm install
npm run build
```

Servește frontend-ul static (prin uvicorn sau nginx):
```bash
# Opțiunea simplă - servire directă cu Python
python3 -m http.server 3000 --directory dist/
```

---

## 2. Configurare

### Variabile de mediu (backend)

| Variabilă        | Default                    | Descriere                    |
|------------------|----------------------------|------------------------------|
| `AOI_DRIVE_ROOT` | `/mnt/aoi`                 | Mount point pentru drive P:/ |
| `AOI_AP_URL`     | `http://intranet.../...`   | URL Auftragsplan             |

Exemplu:
```bash
export AOI_DRIVE_ROOT=/mnt/aoi
uvicorn main:app --host 0.0.0.0 --port 8000
```

### Frontend - URL backend

Dacă frontenidul rulează pe alt host decât backenidul, setează în `frontend/.env`:
```
VITE_API_URL=http://192.168.1.100:8000
```

---

## 3. Autostart cu systemd

### Backend service

```bash
sudo nano /etc/systemd/system/aoi-backend.service
```

```ini
[Unit]
Description=AOI Tool Backend
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/aoi-web/backend
Environment=AOI_DRIVE_ROOT=/mnt/aoi
ExecStart=/home/pi/aoi-web/backend/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable aoi-backend
sudo systemctl start aoi-backend
```

---

## 4. Utilizare

Accesează din browser: `http://<IP_RPI>:3000`

- **Auftragsplan** — inspecție BG-uri din planul de producție zilnic
- **Vorbereitung** — inspecție programe în pregătire
- **Filtrare** — după culoare eroare (Eroare / Atenție / Info / OK)
- **Căutare** — după număr BG sau PP
- **Detalii** — click pe orice rând pentru a vedea erorile și Hinweis-ul

### Culori

| Culoare  | Semnificație                          |
|----------|---------------------------------------|
| 🟢 Verde | Fără erori                            |
| 🟡 Galben| Erori informative (Error_17, 18, ...)  |
| 🟠 Portocaliu | Atenție (PP locked, lipsă fișier) |
| 🔴 Roșu  | Eroare critică (PP lipsă, CLI greșit) |

---

## 5. Structura proiectului

```
aoi-web/
├── backend/
│   ├── main.py              # FastAPI app, endpoints
│   ├── config.py            # Căi centralizate
│   ├── models.py            # Modele Pydantic
│   ├── requirements.txt
│   └── modules/
│       ├── intranet.py      # Scraping AP + citire pl.txt
│       ├── pp_detect.py     # Detectare PP în CadRuest/VB
│       ├── cad_inspect.py   # Inspecție fișiere Viscom SI
│       ├── pipeline.py      # Orchestrare pipeline inspecție
│       └── errors.py        # Gestiune erori (in-memory)
└── frontend/
    ├── src/
    │   ├── App.jsx          # Componenta principală React
    │   └── main.jsx         # Entry point
    ├── index.html
    ├── package.json
    └── vite.config.js
```
