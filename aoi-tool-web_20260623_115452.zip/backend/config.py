"""
AOI Tool - Centralized configuration
Toate căile și URL-urile sunt definite aici, nu hardcodate în logică.
Pe RPi, drive-ul P:/ va fi montat via CIFS, ex: /mnt/aoi
"""

import os

# ─── Mount point ────────────────────────────────────────────────────────────────
# Pe Windows (original): P:/
# Pe RPi cu CIFS mount:  /mnt/aoi  (sau ce ai configurat în /etc/fstab)
# Detectare automată: dacă rulăm pe Windows, folosim P:/ direct
import platform

# ──────────────────────────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────────
EDV_SERVER = "P:/"
AOI_SERVER_PATH = os.path.join(EDV_SERVER, "aoi")

# ──────────────────────────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────────

# ─── Viscom SI paths ─────────────────────────────────────────────────────────────
CAD_RUEST_PATH        = os.path.join(AOI_SERVER_PATH, "Viscom_XM/Project/Si/Data/Cad_Ruest")
CLI_RUEST_PATH        = os.path.join(AOI_SERVER_PATH, "Viscom_XM/Project/Si/Data/Cli_Ruest")
VORBEREITUNG_PATH     = os.path.join(AOI_SERVER_PATH, "Angefangene Programme/Vorbereitung_AOI_XM")
PICTURE_PATH          = os.path.join(AOI_SERVER_PATH, "PICTURE")

# ─── EDV paths ─────────────────────────────────────────────────────────────
BG_INFO_PATH          = os.path.join(EDV_SERVER, "bginfo/8nr")
EMPTY_LP_PATH         = r"\\HAMBURG\Quins_QSWE\QUINSEASY\Projekte"


# ─── Project paths ────────────────────────────────────────────────────────────────
PROJECT_ROOT          = "C:/Users/mcro/Documents/aoi-web/"

DB_PATH               = os.path.join(PROJECT_ROOT, "aoi_tool.db")
LOG_PATH              = os.path.join(PROJECT_ROOT, "logs")
ERRORS_XLS_FILE       = os.path.join(PROJECT_ROOT, "Docs/Errors.xlsx")
IDEAS_FILE            = os.path.join(PROJECT_ROOT, "Docs/ideas.json")
KUNDE_CSV_FILE        = os.environ.get("AOI_KUNDE_CSV",
                            os.path.join(PROJECT_ROOT, "Docs/kunde_names.csv"))


# ─── Intranet ─────────────────────────────────────────────────────────────────────
AP_URL = os.environ.get(
    "AOI_AP_URL",
    "http://intranet.world.se.com/fertigung/info/auftragsplan.cgi?iieborder=1&mode=SMD"
)


# ─── Test paths ─────────────────────────────────────────────────────────────
TEST_PATH = r"C:\Users\mcro\Documents\aoi-web\test"

# Paths
TEST_BG_INFO_PATH =     os.path.join(TEST_PATH, "bg_info")
TEST_CAD_RUEST_PATH =   os.path.join(TEST_PATH, "Cad_Ruest")
TEST_CLI_RUEST_PATH =   os.path.join(TEST_PATH, "Cli_Ruest")
TEST_PICTURE_PATH =     os.path.join(TEST_PATH, "PICTURE")
TEST_EMPTY_LP_PATH =    os.path.join(TEST_PATH, "EMPTY_LP")

TEST_VORBEREITUNG_PATH = VORBEREITUNG_PATH
TEST_IDEAS_FILE = IDEAS_FILE

# Files
TEST_AP_HTML_FILE = os.path.join(TEST_PATH, "ap.html")
TEST_KUNDE_CSV_FILE = KUNDE_CSV_FILE




# ─── Error severity colors ────────────────────────────────────────────────────────
ERROR_COLORS = {
    "red":          "#ef4444",   # roșu - eroare critică
    "orange":       "#f97316",   # portocaliu - sugestie
    "yellow":       "#eab308",   # galben - info
    "green":        "#22c55e",   # verde - ok
}
